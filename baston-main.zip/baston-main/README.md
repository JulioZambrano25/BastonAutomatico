This project is developed with the intention of making it easier for blind people to get around
construction video link:
https://www.youtube.com/watch?v=j0U_htZV3ds
